
var main = require('./Backend/main');
main.startServer(5050);

var http = require('http');
var static = require('node-static');
var file = new static.Server('.');

http.createServer(function(req, res) {
  file.serve(req, res);
}).listen(5050,'127.0.0.1');

console.log('Server running on port 5050');